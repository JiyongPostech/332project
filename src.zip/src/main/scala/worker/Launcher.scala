package worker

import common._
import network._

object Launcher {
  def main(args: Array[String]): Unit = {
    println("=== Worker Launcher Started ===")
    
    // 1) 워커 ID 및 통신 초기화
    val workerId = if (args.nonEmpty) args(0).toInt else 1
    val myUdpPort = 50051 + workerId  // 워커별 포트 할당
    val masterHost = "localhost"
    val masterPort = 50051
    
    val net: NetworkService = new NettyClientService(
      workerId, 
      myUdpPort, 
      masterHost, 
      masterPort
    )

    // 2) 실행기(모듈 호출 래퍼) 준비
    val exec = new NoopTaskExecutor() // TODO: 이후 sample/partition/merge/sort 주입

    // 3) 런타임 구성 및 시작
    val runtime = new WorkerRuntime(workerId, net, exec)
    runtime.start()
    
    println(s"[Worker $workerId] Started and connected to master")

    // ===== 파이프라인 실행 (Main 깔끔하게 구조화) =====
    
    // 데모 시나리오: 파일에서 데이터 읽어 전체 파이프라인 실행
    val inputFile = s"data/input_worker_$workerId.txt"  // 각 워커의 입력 파일
    val outputFile = s"data/output_worker_$workerId.txt"  // 각 워커의 출력 파일
    
    try {
      // === 1단계: 데이터 분석 ===
      println(s"\n[Worker $workerId] === Step 1: Data Analysis ===")
      val analysisResult = runtime.runAnalysis(inputFile)
      
      // 마스터에게 분석 결과 전송 (마스터 ID는 0으로 가정)
      runtime.sendAnalysisToMaster(0, analysisResult)
      
      // === 2단계: 키 범위 수신 대기 (실제로는 비동기 메시지로 받음) ===
      println(s"\n[Worker $workerId] === Step 2: Waiting for Key Ranges from Master ===")
      // 실제 구현에서는 마스터로부터 키 범위를 비동기로 받음
      // 여기서는 데모용으로 임시 키 범위 사용
      Thread.sleep(2000)  // 마스터 응답 대기 시뮬레이션
      
      // === 3단계: 데이터 재분배 (Shuffle) ===
      println(s"\n[Worker $workerId] === Step 3: Data Shuffle ===")
      // 실제로는 마스터로부터 받은 키 범위 사용
      val demoKeyRanges = Seq(
        KeyRange(1, 0, 1000),
        KeyRange(2, 1001, 2000),
        KeyRange(3, 2001, 3000)
      )
      
      // 파일에서 읽은 데이터로 Shuffle
      val dataToShuffle = readDataFromFile(inputFile)
      val myData = runtime.runShuffle(dataToShuffle, demoKeyRanges)
      
      // === 4단계: 데이터 정렬 ===
      println(s"\n[Worker $workerId] === Step 4: Data Sorting ===")
      Thread.sleep(1000)  // Shuffle로 받은 데이터 수신 대기
      val sortedData = runtime.runSort()
      
      // === 5단계: 결과 저장 ===
      println(s"\n[Worker $workerId] === Step 5: Save Results ===")
      runtime.saveSortedData(outputFile)
      
      // === 6단계: 마스터에게 정렬된 데이터 전송 (최종 병합용) ===
      println(s"\n[Worker $workerId] === Step 6: Send Sorted Data to Master ===")
      runtime.sendSortedDataToMaster()
      
      println(s"\n[Worker $workerId] === Pipeline Complete ===")
      
    } catch {
      case e: Exception =>
        println(s"[Worker $workerId] Error during pipeline execution: ${e.getMessage}")
        e.printStackTrace()
    }

    // 종료 대기(데모용)
    println(s"\n[Worker $workerId] Press Enter to stop...")
    scala.io.StdIn.readLine()
    runtime.stop()
    println(s"[Worker $workerId] Stopped")
  }
  
  /**
   * 파일에서 데이터 읽기 (헬퍼 함수)
   */
  private def readDataFromFile(filePath: String): Seq[Long] = {
    try {
      val source = scala.io.Source.fromFile(filePath)
      try {
        source.getLines()
          .map(_.trim)
          .filter(_.nonEmpty)
          .map(_.toLong)
          .toSeq
      } finally {
        source.close()
      }
    } catch {
      case e: Exception =>
        println(s"Warning: Could not read file $filePath, using empty data")
        Seq.empty
    }
  }
}
